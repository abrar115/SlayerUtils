
import Settings from "../Amaterasu/core/Settings"
import DefaultConfig from "../Amaterasu/core/DefaultConfig"
import { dataAA } from "./data.js"
import { ResetCombatXp } from "./Features/PetChcker.js"

const schemes = ["data/ColorScheme.json", "data/scheme-vigil.json", "data/scheme-nwjn.json"]




const CHANGELOG = `No Changes yet :D`
const CREDITS = FileLib.read("Amaterasu", "CREDIT.md")
const defaultConf = new DefaultConfig("SlayerUtils", "data/settings.json")

.addSwitch({
    category: "Slayer",
    configName: "Combat Overlay",
    title: "Combat Overlay",
    description: "Toggles Combat Exp Overlay.",
    tags: ["overlay", "render", "combat"],
   registerListener(previous, now){  
    if (now == true)      {
            dataAA.combat = true
        ChatLib.chat(`&b&l Combat Exp Overlay &f&lToggled &7[§aEnabled&7]`)
    }
       else{
        dataAA.combat = false
         ChatLib.chat(`&b&l Combat Exp Overlay &f&lToggled &7[&cDisabled&7]`)
       } }
})

.addSwitch({
    category: "Slayer",
    configName: "Pet Overlay",
    title: "Pet Overlay",
    description: "Toggles Pet Exp Overlay.",
    tags: ["overlay", "render", "pet"],
    registerListener(previous, now){  
    if (now == true)      {
            dataAA.pet = true
       ChatLib.chat(`&b&l Pet Exp Overlay &f&lToggled &7[§aEnabled&7]`)
    }
       else{
        dataAA.pet = false
        ChatLib.chat(`&b&l Pet Exp Overlay &f&lToggled &7[&cDisabled&7]`)
       } }
})

.addButton({
    category: "Slayer",
    configName: "Reset Combat Xp",
    title: "Reset Combat Overlay",
    description: "Resets Combat Exp Overlay.",
    tags: ["reset",  "combat"],
    onClick(setting){
            ResetCombatXp()
            
    }
})


        const config = new Settings("SlayerUtils", defaultConf, "data/ColorScheme.json")

    
    .setCommand("Su", ["su"])

   
    .addMarkdown("Changelog", CHANGELOG)
    .addMarkdown("Credits", CREDITS)

    
    

const currentScheme = schemes[config.settings.scheme]
const scheme = JSON.parse(FileLib.read("SlayerUtils", currentScheme))




FileLib.write("SlayerUtils", currentScheme, JSON.stringify(scheme, null, 4))


config
    .setPos(config.settings.x, config.settings.y)
    .setSize(config.settings.width, config.settings.height)
    
    .apply()

export default config.settings