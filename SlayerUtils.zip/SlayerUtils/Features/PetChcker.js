import { dataAA } from "../data.js"

const prefix1 = `&6[SlayerUtils]`

const PetMessage = new TextComponent(`${prefix1} &5&lNo Pet Equipped, Please Equip Desired Pet To Calculate Pet Exp Per Hour.`).setHoverValue("&bClick To Open Pets Menu").setClick("run_command", "/pets")
const Taming = new TextComponent(`${prefix1} &5&lTaming Level Not Updated, Please Do /skills.`).setHoverValue("&bClick To Open Skills Menu").setClick("run_command", "/skills")
const Beastmaster = new TextComponent(`${prefix1} &5&lBeastmaster Crest Not Found, Please Open Accessory Bag.`).setHoverValue("&bClick To Open Accessory Bag").setClick("run_command", "/ab")


let insb = false
let times = 0
let clickedWarnings = {
    ab: false,
    pet: false,
    skills: false
};
function isSkyblock() {
    let skyblock = ChatLib.removeFormatting(Scoreboard.getTitle())
    
    if (skyblock == "SKYBLOCK") {
       
        insb = true
    }
    else {
         
        insb = false
    }
}

const petTypeMap = {            
    "Combat Pet": "Combat",
    "Combat Mount": "Combat",
    "Mining Pet": "Mining",
    "Mining Mount": "Mining",
    "Fishing Pet": "Fishing",
    "Farming Pet": "Farming",
    "Foraging Pet": "Foraging",
    "Enchanting Pet": "Enchanting",
}
let displayName = ""
let heldItem = null
let heldItemBoost = null
let petType = "Unknown"
let heldItemBoostValue = 0
let PetTypeValue
register("guiOpened", () => {
    setTimeout(() => {
        const inv = Player.getOpenedInventory()
        if (!inv) return

        const title = ChatLib.removeFormatting(inv.getName())
        if (!title.includes("Pets")) return

        let foundEquippedPet = false

       for (let i = 0; i < inv.getSize(); i++) {
    let item = inv.getStackInSlot(i)
    if (!item) continue

    let lore = item.getLore().map(line => ChatLib.removeFormatting(line))
    if (lore.length === 0) continue

    let isEquipped = false
    heldItem = null
    heldItemBoost = null
    petType = "Unknown"
    heldItemBoostValue = 1  

    for (let j = 0; j < lore.length; j++) {
        let line = lore[j]

        if (line.toLowerCase().includes("click to despawn")) isEquipped = true

     if (line.startsWith("Held Item:")) {
    heldItem = line.replace("Held Item:", "").trim();
    heldItemBoost = (j + 1 < lore.length) ? lore[j + 1].trim() : null;

    heldItemBoostValue = 1;  

    if (heldItemBoost && heldItemBoost.toLowerCase().includes("exp")) {
        const match = heldItemBoost.match(/\+(\d+)%/);
        if (match) {
            heldItemBoostValue = parseInt(match[1]);
        }
    }

    
}
      for (const rawType in petTypeMap) {
            if (line.includes(rawType)) {
                petType = petTypeMap[rawType]
                break
            }
        }
    }

    if (isEquipped) {
        foundEquippedPet = true    
        displayName = ChatLib.removeFormatting(item.getName())
        ChatLib.chat(`${prefix1} &b&lEquipped Pet Detected: ${displayName}`)
        break
    }
}
        if (!foundEquippedPet) {
            ChatLib.chat(`${prefix1} &b&lNo pet detected to be equipped. Equip a pet or go to the next page.`)
        }
        if (petType == "Combat") {
            PetTypeValue = 1
        }
        else {
            PetTypeValue = 1/3
        }

        if (heldItem.includes("Combat")) {
            heldItemBoostValue = heldItemBoostValue
            
        }
        else {
            heldItemBoostValue = 1
            
        }
    }, 100) 
})



register("step", () => {
    isSkyblock()
    if (insb == true && displayName === "" && times < 5) {
        times++
        ChatLib.chat(PetMessage)
    }
}).setDelay(10)

let level = 1
register("guiOpened", () => {                 
    setTimeout(() => {
        let inv = Player.getOpenedInventory()
        if (!inv) return

        let title = ChatLib.removeFormatting(inv.getName())
        if (!title.includes("Your Skills")) return
       

        for (let i = 0; i < inv.getSize(); i++) {
            let item = inv.getStackInSlot(i)
            
            let  name = ChatLib.removeFormatting(item.getName()).trim()

            if (name.startsWith("Taming ")) {
                level = name.split(" ")[1]
                ChatLib.chat(`${prefix1} &b&lFound Taming Level: ${level}`)
                break
            }

        }
    }, 100)
})


register("step", ()=>{
    isSkyblock()
    if (insb == true && level == 1 && times < 5) {
        times++
        ChatLib.chat(Taming)
    }
}).setDelay(10)

let found = false 
let petboost = 0

register("guiOpened", () => {                          
    setTimeout(() => {
        let inv = Player.getOpenedInventory()
        if (!inv) return

        let title = ChatLib.removeFormatting(inv.getName())
        if (!title.includes("Accessory Bag")) return

        found = false
        petboost = 0
        for (let i = 0; i < inv.getSize(); i++) {
            let item = inv.getStackInSlot(i)
            if (!item || item.getName() === null || item.getName().includes("AIR")) continue
            let lore = item.getLore().map(line => ChatLib.removeFormatting(line))
            if (lore.length === 0) continue
            for (let j = 0; j < lore.length; j++) {
                let line = lore[j]
                if (line.startsWith("Pet Exp Boost:")) {
                    petboost = line.replace("Pet Exp Boost: +", "").trim()
                    
                    if (j + 1 < lore.length) heldItemBoost = lore[j + 1].trim()
                }
            }
            let name = ChatLib.removeFormatting(item.getName()).trim()
            if (name.toLowerCase().includes("beastmaster crest")) {
                found = true
                ChatLib.chat(`${prefix1} &b&lFound: ${name} || Pet Boost: ${petboost}`)
                break
            }
        }
        if (!found && times < 5) {
            times++
            ChatLib.chat(`${prefix1} &5&lNo Beastmaster Crest found in Accessory Bag.`)
        }
    }, 150) 
})


register("step", ()=>{
    isSkyblock()
    if (insb == true && found == false && times < 5 ) {
        times++
        ChatLib.chat(Beastmaster)
    }
}).setDelay(10)



let tracking = false
let startXP = 0
let lastXP = 0
let startTime = 0
let lastKnownXP = 0
let gained = 0 
function formatNumber(num) {
    num = Number(num)
    if (num >= 1e9) return (num / 1e9).toFixed(2) + "b"
    if (num >= 1e6) return (num / 1e6).toFixed(2) + "m"
    if (num >= 1e3) return (num / 1e3).toFixed(2) + "k"
    return num.toFixed(2)
}

export function ResetCombatXp(){
     const item = Player.getHeldItem()
    if (!item) {
        ChatLib.chat(`${prefix1} §cHold a Champion weapon to reset tracker.`)
        return
    }

    const nbt = item.getNBT()?.toObject()
    const xp = nbt?.tag?.ExtraAttributes?.champion_combat_xp

    if (xp === undefined) {
         ChatLib.chat(`${prefix1} §b&lNo Champion Found On This Weapon.`)
        return
    }

    tracking = false
    startXP = xp
    lastXP = xp
    lastKnownXP = xp
    startTime = 0
    seenInitialXP = false
    
    ChatLib.chat(`${prefix1} §b&lChampion XP tracker reset `)
}

register("command", () => {
ResetCombatXp()
    
}).setName("resetxp").setAliases("rsxp")

register("command", ()=>{
   if (dataAA.combat == true) dataAA.combat = false
    else dataAA.combat = true
    ChatLib.chat(`&8➤&b&l Combat Exp Overlay &f&lToggled &7[&d${dataAA.combat}&7]`)
}).setName("toggleCombat", true).setAliases("tcr")



register("command", ()=>{    
 if (dataAA.pet == true) dataAA.pet = false
    else dataAA.pet = true
    ChatLib.chat(`&8➤&b&l Pet Exp Overlay &f&lToggled &7[&d${dataAA.pet}&7]`)
}).setName("togglePet", true).setAliases("tpr")


let seenInitialXP = false

register("step", () => {
    const item = Player.getHeldItem()
    if (!item) return

    const nbt = item.getNBT()?.toObject()
    const xp = nbt?.tag?.ExtraAttributes?.champion_combat_xp
    if (xp === undefined) return

    if (!seenInitialXP) {
        lastXP = xp
        seenInitialXP = true
        return 
    }

    
    if (!tracking && xp > lastXP) {
        tracking = true
        startXP = lastXP
        startTime = Date.now()
        
    }

    lastXP = xp
    lastKnownXP = xp
}).setFps(2)

const beastmasterBonus = 1 + (parseFloat(petboost / 100));
const tamingBonus = 1 + (parseFloat(level / 100))
const heldItemBonus = 1 + (parseFloat(heldItemBoostValue / 100));
const effectiveXP = gained * beastmasterBonus;
petXP = effectiveXP * tamingBonus * heldItemBonus * PetTypeValue




let shouldCloseGUI = false;
let closeGUITickCounter = 0;
let isHovering = false
let petCommand = ""




let petXP = 0
register("renderOverlay", () => {
   if (insb && dataAA.combat == true) {
    if (lastKnownXP === 0 ) {
        
        if (!Player.getHeldItem()) {
            Renderer.drawString("§cNo weapon held", 10, 10)
        } else {
            Renderer.drawString("§7Champion XP not tracked yet", 10, 10)
        }
        return
    }

    gained = 0
    let elapsedMin = 0
    let xpPerHour = 0

    if (tracking) {
        gained = Math.floor(lastKnownXP) - Math.floor(startXP)
        elapsedMin = (Date.now() - startTime) / 60000
        xpPerHour = elapsedMin > 0 ? (gained * 60 / elapsedMin) : 0
    }

    Renderer.drawString("§aChampion XP Tracker", 10, 10)
   

    if (tracking) {
       Renderer.drawString("§bChampion XP Tracker", 10, 10);         

Renderer.drawString("§3Gained: §b" + formatNumber(gained), 10, 34)
Renderer.drawString("§3Time: §b" + elapsedMin.toFixed(1) + " Min", 10, 46)
Renderer.drawString("§3Rate: §b" + formatNumber(xpPerHour) + " xp/Hour", 10, 58)

    } else {
        Renderer.drawString("§cTracking not started, Gain Combat Exp To Start.", 10, 34)
    }
}

if (insb && dataAA.pet == true){    
    if (lastKnownXP === 0 || !tracking) return;
     
   
    const baseXP = lastKnownXP - startXP;
    const elapsedMin = (Date.now() - startTime) / 60000;
    const petXPPerHour = elapsedMin > 0 ? (petXP * 60 / elapsedMin) : 0;

    const mouseX = Client.getMouseX();
    const mouseY = Client.getMouseY();

    let x = 10;
    let y = 80;

    Renderer.drawString("§dPet XP Tracker", x, y); y += 12;
    Renderer.drawString(`§ePet: §b${displayName}`, x, y); y += 12;
    Renderer.drawString(`§3Pet XP Gained: §b${formatNumber(petXP)}`, x, y); y += 12;
    Renderer.drawString(`§3Rate: §b${formatNumber(petXPPerHour)} xp/hr`, x, y); y += 12;

  function drawWarning(text, command) {
    if (clickedWarnings[command]) return;

    const width = Renderer.getStringWidth(text);
    const height = 10;

    isHovering = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;

    if (isHovering) {
        Renderer.drawRect(Renderer.color(0, 0, 0, 100), x - 2, y - 1, width + 4, height + 2);
        petCommand = command;
    }

    Renderer.drawString(text, x, y);
    y += 12;
}

     if (!found) drawWarning("§c⚠ Beastmaster Crest not found || => [Click to open 3rd]", "ab");
     if (heldItemBoostValue === 0)   drawWarning("§c⚠ Pet Is Not Detected — open /pet || => [Click to open 2nd]",  "pet")
     if (parseInt(level) === 1) drawWarning("§c⚠ Taming Level is 1 — open /skills || => [Click to open 1st]",  "skills"); 

}})


register("clicked", () => {
    if (isHovering && petCommand && !clickedWarnings[petCommand]) {
        ChatLib.say("/" + petCommand);
        clickedWarnings[petCommand] = true; 
        isHovering = false;
        petCommand = "";
        shouldCloseGUI = true
        World.playSound("mob.cat.meow", 1, 2);

    }
});

register("tick", ()=>{
     if (shouldCloseGUI){
        closeGUITickCounter++
        if (closeGUITickCounter>=20){ 
        const currentGui = Client.getCurrentGui();
           currentGui.close()
             shouldCloseGUI = false
             closeGUITickCounter = 0
        }
     }
})